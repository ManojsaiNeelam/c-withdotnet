﻿// See https://aka.ms/new-console-template for more information

//step-1 using namespace
using MyPractiseClassLibrary1;
using MyPractiseClassLibrary1.Models;
using StructuresDemo;
using System.ComponentModel;
using System.Drawing;
using static MyPractiseClassLibrary1.EnumDemo;
{
    //step-2 creating an object
    Class1 obj = new Class1();


    //step-3 calling the object values
    Console.WriteLine(obj.a);
    Console.WriteLine(obj.name);
    Console.WriteLine(" -------------------");
    obj.FirstName = "ROHITH REDDY";
    Console.WriteLine(obj.FirstName);
    Console.WriteLine(" -------------------");
    obj.LastName = "GALI";
    Console.WriteLine(obj.LastName);
    Console.WriteLine(" -------------------");
    obj.Email = "rrg527@gmail.com";
    Console.WriteLine(obj.Email);
    Console.WriteLine(" -------------------");
    obj.Dob = Convert.ToDateTime("11/20/1990");//DateTime.Now; //
    Console.WriteLine(obj.Dob);
    Console.WriteLine(" -------------------");
    obj.Address = "Kukatpally";
    Console.WriteLine(obj.Address);
    Console.WriteLine(" -------------------");
    Console.WriteLine(obj.FullName);
    Console.WriteLine(" -------------------");

    obj.AddTwoNumbers();
    obj.SubstractTwoNumbers();
    obj.MultiplyTwoNumbers();
    obj.DivideTwoNumbers();

    Console.WriteLine(" ---with return type----------------");
    int z = obj.AddAandB();
    Console.WriteLine(z);
    Console.WriteLine(" ---with return type and paramneters----------------");
    int x = obj.AddCandD(100, 200);
    Console.WriteLine(x);
    Console.WriteLine(" ---with return type and default/optional paramneters----------------");
    int y = obj.AddEandF(200);
    Console.WriteLine(y);
    Console.WriteLine(" ------Static class-------------");
    Console.WriteLine(MyStaticClass1.i);
    Console.WriteLine(" ------example inheritance class-------------");
    ChildClass objcc = new ChildClass();
    Console.WriteLine(objcc.a);
    Console.WriteLine(objcc.Name = "ClassField");
    objcc.AddTwoNumbers(300, 400);
    Console.WriteLine(" ------example Interphase class-------------");
    objcc.MyAmount();
    objcc.XYZ();
    objcc.ABC();
    Console.WriteLine(" ------example polymorphism method overloading early binding class-------------");
    PloymorphismDemo objp = new PloymorphismDemo();
    Console.WriteLine(objp.GetMyValue(2, 3, 4));
    Console.WriteLine(objp.GetMyValue(1, 2001));
    Console.WriteLine(objp.GetFullName());
    Console.WriteLine(objp.GetFullName("ROHITH", "REDDY", "GALI"));
    Console.WriteLine(" ------example polymorphism method overriding late binding class-------------");
    ChildRunTimePolymorphismDemo objc = new ChildRunTimePolymorphismDemo();
    Console.WriteLine(objc.GetMoney());
    ChildEmployee ce = new ChildEmployee();
    Console.WriteLine(ce.GetMoney());
    Console.WriteLine(" ------example abstract class-------------");//we cannot create instance for abstract class
    ABSChild objabs = new ABSChild();
    objabs.AbstractMethod();
    Console.WriteLine(" ------example for structures-------------");
    StructRectangle r1 = new StructRectangle(10, 5);
    r1.AreaofRectangle();
    Console.WriteLine(" ------example for Enums-------------");
    WeekDays wd = EnumDemo.WeekDays.Monday;
    Console.WriteLine(wd);
    int we = (int)EnumDemo.WeekEnds.Sunday;
    Console.WriteLine(we);
    Console.WriteLine(" ------example for Indexers-------------");
    IndexesDemo objid = new IndexesDemo(1, "Rohith", 15000);
    Console.WriteLine(objid[0]);
    Console.WriteLine(objid[1]);
    Console.WriteLine(objid[2]);
    objid[1] = "Rohith Reddy";
    Console.WriteLine(objid[1]);
    Console.WriteLine(" ------example for Delegates-------------");
    DelegateDemo objdm = new DelegateDemo();
    CalculatorDelegate objcal = new CalculatorDelegate(objdm.Add);
    Console.WriteLine(objcal(20, 30));
    objcal = objdm.Mul;
    Console.WriteLine(objcal(2, 4));
    objcal = objdm.Sub;
    Console.WriteLine(objcal(4, 2));
    Console.WriteLine(" ------example for Arrays-------------");
    ArraysDemo ar = new ArraysDemo();
    ar.DisplayArray();
    ar.DisplayArrayNames();
    ar.DisplayNumbers();
    Console.WriteLine(" ------example for Generics-------------");
    GenericsDemo<int> gd = new GenericsDemo<int>();
    gd.GetNumbers();
    GenericsDemo<string> gd1 = new GenericsDemo<string>();
    gd1.GetNames();
    GenericsDemo<object> gd2 = new GenericsDemo<object>();
    gd2.GetNumbersAndNames();
    Console.WriteLine(" ------example for ADO.net-------------");
    //MyDataBaseSample1 objdata = new MyDataBaseSample1();
    //objdata.SampleADOConnectionMethod();
    //objdata.SampleADOConnectionMethod1();
    //MyDataBaseSample2 obj2 = new MyDataBaseSample2();
    //obj2.AdoConnectionMethod2();
    //MyDataBaseSample3 obj3 = new MyDataBaseSample3();
    //obj3.GetAllSpecialitiesByID();
    //MyDemoDBSAmpleClass obj4 = new MyDemoDBSAmpleClass();
    //obj4.GetAllCategories();
    //obj4.GetAllCategoriesbyID();
    //obj4.GetCustomersbyID(1);
    //Categories objcategories = new Categories();
    //List<Categories> lst = objcategories.GetCategories();
    //foreach (var item in lst)
    //{
    //    Console.WriteLine("{0},{1},{2}",item.CategoryID,item.CategoryName,item.Description );
    //}
    //Customers objcustomers = new Customers();
    //List <Customers> list= objcustomers.GetCustomers();
    //foreach (var item in list)
    //{
    //    Console.WriteLine("{0},{1},{2},{3},{4},{5},{6}",item.CustomerID,item.CustomerName,item.ContactName,item.Address,item.City,item.PostalCode,item.Country);
    //}
    //Employees e = new Employees();
    //List<Employees> list = e.GetEmployees();
    //foreach (var item in list)
    //{
    //    Console.WriteLine("{0},{1},{2},{3},{4},{5}",item.EmployeeID,item.LastName,item.FirstName,item.BirthDate,item.Photo,item.Notes);
    //}
    //SqlDataAdapterDemo sdademo = new SqlDataAdapterDemo();
    //sdademo.GetCategoriesbyDataAdapter();
    Console.WriteLine("Dependency injection trials");
    ISampleinterface1 i1 = new DependencyInjectionDemoClass();

