﻿using System;

namespace StructuresDemo
{
    public struct StructRectangle
    {
        private int length;
        private int breath;

       
        public StructRectangle(int a,int b)
        {
            this.length = a;
            this.breath=b;
        }
        public void AreaofRectangle()
        {
            Console.WriteLine("Area is: ");
            Console.WriteLine(length * breath);
        }
    }

}
