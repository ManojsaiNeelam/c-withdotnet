﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MyPractiseClassLibrary1
{
    public class IndexesDemo
    {
        private int eno;
        private string ename;
        private double esalary;

        public IndexesDemo(int eno,string ename,double esalary)
        {
            this.eno = eno;
            this.ename = ename;
            this.esalary = esalary;
        }
        public object this[int index]// is indexer for the class IndexesDemo class
        {
            get
            {
                if (index == 0)
                    return eno;
                else if (index == 1)
                    return ename;
                else if (index == 2)
                    return esalary;
                else
                    return null;
            }
            set
            {
                if (index == 0)
                    eno = (int)value;
                else if (index == 1)
                    ename = (string)value;
                else if (index == 2)
                    esalary = (double)value;
            }
        }
    }
}
