﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace MyPractiseClassLibrary1
{
   public class MyDataBaseSample2
    {

        public void AdoConnectionMethod2()
        {
            string connectionstring = "Data Source=RRG;Initial Catalog=Hospital_DB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
            SqlConnection objofsqlconnection = new SqlConnection(connectionstring);
            objofsqlconnection.Open();
            Console.WriteLine("Connection to database is successfully done");

            string command = "Select * from [dbo].[Nurse_roles]";
            SqlCommand objofsqlcommand = new SqlCommand(command, objofsqlconnection);
            objofsqlcommand.CommandType = CommandType.Text;

            SqlDataReader objofsqlreader = objofsqlcommand.ExecuteReader();

            if (objofsqlreader.HasRows)
            {
                while(objofsqlreader.Read())
                {
                    Console.WriteLine("{0},{1},{2},{3}", objofsqlreader["Nurse_Role_ID"], objofsqlreader["Nurse_Role_Name"], objofsqlreader["Nurse_Role_Description"], objofsqlreader["Nurse_Role_Code"]);
                }
            }
            objofsqlconnection.Close();
            Console.WriteLine("Connection closed");
        }
    }
}
