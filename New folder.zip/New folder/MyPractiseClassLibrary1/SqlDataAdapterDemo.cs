﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Data;
using MyPractiseClassLibrary1.Models;
using System.Collections.Concurrent;

namespace MyPractiseClassLibrary1
{
    public class SqlDataAdapterDemo
    {
        public int CategoryID { get; set; }
        public string? CategoryName { get; set; }
        public string? Description { get; set; }

        public void GetCategoriesbyDataAdapter()
        {
            //List<Categories> listofcategoriesbydataadapter = new List<Categories>();
            string connectionstring = "Data Source=RRG;Initial Catalog=Demo_DB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
            SqlConnection sqlconnection = new SqlConnection(connectionstring);
            sqlconnection.Open();
            Console.WriteLine("Connection successfull");
            string command = "select * from Categories";
            //SqlCommand sqlcommand = new SqlCommand(command,sqlconnection);
            SqlDataAdapter sda = new SqlDataAdapter(command, sqlconnection);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                Console.WriteLine("{0}, {1}, {2} ", row[0], row[1], row[2]);
            }
            Console.WriteLine("----------------------------------------------");
            DataTable dt = new DataTable();
            sda.Fill(dt);
            foreach (DataRow row in dt.Rows)
            {
                Console.WriteLine("{0},{1},{2}", row[0], row[1], row[2]);
            }
        }
    }
}
