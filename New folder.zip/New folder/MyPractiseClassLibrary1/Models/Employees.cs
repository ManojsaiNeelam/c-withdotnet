﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace MyPractiseClassLibrary1.Models
{
    public class Employees
    {
        public int EmployeeID { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string BirthDate { get; set; }
        public string Photo { get; set; }
        public string Notes { get; set; }

        public List<Employees> GetEmployees()
        {
            List<Employees> listofemployees = new List<Employees>();

            string connectionstring = "Data Source=RRG;Initial Catalog=Demo_DB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
            SqlConnection objsqlconnection = new SqlConnection(connectionstring);
            objsqlconnection.Open();
            Console.WriteLine("Connection done successfully");
            string command = "Select * from Employees";
            SqlCommand objsqlcommand = new SqlCommand(command,objsqlconnection);
            objsqlcommand.CommandType = CommandType.Text;
            SqlDataReader objsqldatareader = objsqlcommand.ExecuteReader();

            if (objsqldatareader.HasRows)
            {
                while (objsqldatareader.Read())
                {
                    Employees e = new Employees();
                    e.EmployeeID = Convert.ToInt32(objsqldatareader["EmployeeID"]);
                    e.LastName = Convert.ToString(objsqldatareader["LastName"]);
                    e.FirstName = Convert.ToString(objsqldatareader["FirstName"]);
                    e.BirthDate = Convert.ToString(objsqldatareader["BirthDate"]);
                    e.Photo = Convert.ToString(objsqldatareader["Photo"]);
                    e.Notes = Convert.ToString(objsqldatareader["Notes"]);
                    listofemployees.Add(e);
                }
            }
            return listofemployees;
        }
    }
}
