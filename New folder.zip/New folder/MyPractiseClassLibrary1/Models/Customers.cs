﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPractiseClassLibrary1.Models
{
    public class Customers
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string ContactName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public string Country { get; set; }
       
        public List<Customers> GetCustomers()
        {
            List<Customers> customerslist = new List<Customers>();
            string connectionstring = "Data Source=RRG;Initial Catalog=Demo_DB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
            SqlConnection objsqlconnection = new SqlConnection(connectionstring);
            objsqlconnection.Open();
            Console.WriteLine("Connection Successful");
            string command = "select * from Customers";
            SqlCommand objsqlcommand = new SqlCommand(command, objsqlconnection);
            objsqlcommand.CommandType = CommandType.Text;

            SqlDataReader objsqldr = objsqlcommand.ExecuteReader();

            if(objsqldr.HasRows)
            {
                while(objsqldr.Read())
                {
                    Customers c = new Customers();
                    c.CustomerID = Convert.ToInt32(objsqldr["CustomerID"]);
                    c.CustomerName = Convert.ToString(objsqldr["CustomerName"]);
                    c.ContactName = Convert.ToString(objsqldr["ContactName"]);
                    c.Address = Convert.ToString(objsqldr["Address"]);
                    c.City = Convert.ToString(objsqldr["City"]);
                    c.PostalCode = Convert.ToString(objsqldr["PostalCode"]);
                    c.Country = Convert.ToString(objsqldr["Country"]);
                    customerslist.Add(c);
                }
            }
            return customerslist;
        }
    }
}
