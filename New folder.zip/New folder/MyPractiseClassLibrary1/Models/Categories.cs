﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPractiseClassLibrary1.Models
{
    public class Categories
    {
        public int CategoryID { get; set; }
        public string? CategoryName { get; set; }
        public string? Description { get; set; }

        public List<Categories> GetCategories()
        {
            List<Categories> listcategory = new List<Categories>();
            string connectionstring = "Data Source=RRG;Initial Catalog=Demo_DB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
            SqlConnection objofsqlconnection = new SqlConnection(connectionstring);
            objofsqlconnection.Open();
            Console.WriteLine("Connection to database is successfully done");

            string command = "Select * from Categories";
            SqlCommand objofsqlcommand = new SqlCommand(command, objofsqlconnection);
            objofsqlcommand.CommandType = CommandType.Text;

            SqlDataReader objofsqlreader = objofsqlcommand.ExecuteReader();

            if (objofsqlreader.HasRows)
            {
                while (objofsqlreader.Read())
                {
                    Categories objcategories = new Categories();
                    objcategories.CategoryID = Convert.ToInt32(objofsqlreader["CategoryID"]);
                    objcategories.CategoryName = Convert.ToString(objofsqlreader["CategoryName"]);
                    objcategories.Description = Convert.ToString(objofsqlreader["Description"]);
                    listcategory.Add(objcategories);
                }
            }
            return listcategory;
        }
    }
}