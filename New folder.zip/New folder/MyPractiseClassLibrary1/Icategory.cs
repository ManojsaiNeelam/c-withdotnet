﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPractiseClassLibrary1
{
    public interface Icategory//contains definitions only
    {
        public void MyAmount();
        public void ABC();
        void XYZ();

    }
}
