﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPractiseClassLibrary1
{
    public abstract class AbstractionDemo
    {
       
        public string name = "RRGALI";
        public abstract void AbstractMethod();
       
    }
    public class ABSChild : AbstractionDemo
    {
        public override void AbstractMethod()
        {
            Console.WriteLine("Abstract Method is called");
        }
    }

}
