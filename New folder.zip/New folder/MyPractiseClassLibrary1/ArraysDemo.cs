﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MyPractiseClassLibrary1
{
    public class ArraysDemo
    {
        int[] numbers = { 1, 2, 3, 4, 5 };
        string[] names = { "Rohith", "Reddy", "Gali" };
        double[] marks = new double[2] { 70.9, 89.7 };
        
        public void DisplayArray()
        {
            for (int i = 0; i < marks.Length; i++)
            {
                Console.WriteLine(marks[i]);
            }
        }
        public void DisplayArrayNames()
        {
            for (int i = 0; i < names.Length; i++)
            {
                Console.WriteLine(names[i]);
            }
        }
        public void DisplayNumbers()
        {
            Console.WriteLine(numbers[0]);
            Console.WriteLine(numbers[1]);
            Console.WriteLine(numbers[2]);
            Console.WriteLine(numbers[3]);
            Console.WriteLine(numbers[4]);
        }
    }
}
