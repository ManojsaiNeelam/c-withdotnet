﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPractiseClassLibrary1
{
    public class ParentRunTimePolymorphismDemo
    {
        public virtual int GetMoney()
        {
            Console.WriteLine("This is parent method");
            int x = 100;
            return x;
        }

    }
    public class ChildRunTimePolymorphismDemo : ParentRunTimePolymorphismDemo
    {
        public override int GetMoney()
        {
            Console.WriteLine("This is Child method");
            int x = 200;
            return x;
        }
    }
    public class ChildEmployee : ParentRunTimePolymorphismDemo
    {
        public override int GetMoney()
        {
            Console.WriteLine("This is child employee method");
            int x = 678;
            return x;

        }
    }
}
