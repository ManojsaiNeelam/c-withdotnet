﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPractiseClassLibrary1
{
    public class PloymorphismDemo
    {
        //method overloading
        public int GetMyValue(int a,int b)
        {
            int c = a + b;
            return c;
        }
        public int GetMyValue(int a, int b,int d)
        {
            int c = a + b + d;
            return c;
        }
        public string GetFullName()
        {
            string fn = "rohith";
            string mn = "reddy";
            string ln = "gali";
            string fullName=( fn+" "+ mn + " "+ln );
            return fullName;
        }

        public string GetFullName(string fn,string mn,string ln)
        {
            string fullname= (fn + " " + mn + " " + ln);
            return fullname;
        }

    }
}
