﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
 
namespace MyPractiseClassLibrary1//namespace is collection of classes
{
    public class ParentClass
    {
        public int a = 0;// field
        private string _name;
        public string Name //Properties
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public void AddTwoNumbers(int a,int b)//method having no retyrn type and with parameters
        {
            int result = 0;
            Console.WriteLine(result=a+b);
        }
    }
    public class ExtraClass
    {
        public string extraclassfield = "ExtraclassField";
    }
    public class ChildClass:ParentClass, Icategory //single inheritance
    {
        public int x = 100;
        public void MyAmount()
        {
            int amount = 100;
            Console.WriteLine(amount);
        }
        public void ABC()
        {
            string name = "ABC";
            Console.WriteLine(name);
        }
        public void XYZ()
        {
            char x = 'X';
            char y = 'Y';
            char z = 'Z';
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine(z);
        }
     
    }
}
