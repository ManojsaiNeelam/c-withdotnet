﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace MyPractiseClassLibrary1
{
    public class MyDemoDBSAmpleClass
    {
        public void GetAllCategories()
        {
            string connectionstring = "Data Source=RRG;Initial Catalog=Demo_DB;Integrated Security=True;Trust Server Certificate=True";
            SqlConnection objsqlconnection = new SqlConnection(connectionstring);
            objsqlconnection.Open();
            Console.WriteLine("Connection Success");
            string command = "Select * from Categories";
            SqlCommand objsqlcommand = new SqlCommand(command, objsqlconnection);
            objsqlcommand.CommandType = CommandType.Text;
            SqlDataReader objsqldatareader = objsqlcommand.ExecuteReader();
            if(objsqldatareader.HasRows)
            {
                while(objsqldatareader.Read())
                {
                    Console.WriteLine("{0},{1},{2}", objsqldatareader["CategoryID"], objsqldatareader["CategoryName"], objsqldatareader["Description"]);
                }
            }
            objsqlconnection.Close();
            Console.WriteLine("Connection Closed");
        }
        public void GetAllCategoriesbyID()
        {
            string connectionstring = "Data Source=RRG;Initial Catalog=Demo_DB;Integrated Security=True;Trust Server Certificate=True";
            SqlConnection objsqlconnection = new SqlConnection(connectionstring);
            objsqlconnection.Open();
            Console.WriteLine("Connection Success");
            string command = "GetCategoriesbyID";
            SqlCommand objsqlcommand = new SqlCommand(command, objsqlconnection);
            objsqlcommand.CommandType = CommandType.StoredProcedure;
            objsqlcommand.Parameters.Add(new SqlParameter("id",1));
            SqlDataReader objsqldatareader = objsqlcommand.ExecuteReader();
            if (objsqldatareader.HasRows)
            {
                while (objsqldatareader.Read())
                {
                    Console.WriteLine("{0},{1},{2}", objsqldatareader["CategoryID"], objsqldatareader["CategoryName"], objsqldatareader["Description"]);
                }
            }
            objsqlconnection.Close();
            Console.WriteLine("Connection Closed");
        }
        public void GetCustomersbyID(int id)
        {
            string connectionstring = "Data Source=RRG;Initial Catalog=Demo_DB;Integrated Security=True;Trust Server Certificate=True";
            SqlConnection objsqlconnection = new SqlConnection(connectionstring);
            objsqlconnection.Open();
            Console.WriteLine("Connection Succeeded");
            string command = "GetCustomersbyID";
            SqlCommand objsqlcommand = new SqlCommand(command, objsqlconnection);
            objsqlcommand.CommandType = CommandType.StoredProcedure;
            objsqlcommand.Parameters.Add(new SqlParameter("@id", id));
            SqlDataReader objsqldatareader = objsqlcommand.ExecuteReader();
            if(objsqldatareader.HasRows)
            {
                while(objsqldatareader.Read())
                {
                    Console.WriteLine("CustomerID:{0},CutomerName:{1},ContactName:{2},Address:{3},City:{4},PostalCode:{5},Country:{6}", objsqldatareader["CustomerID"], objsqldatareader["CustomerName"], objsqldatareader["ContactName"], objsqldatareader["Address"], objsqldatareader["City"], objsqldatareader["PostalCode"], objsqldatareader["Country"]);
                }
            }
            objsqlconnection.Close();
            Console.WriteLine("Connection Closed");
        }
    }
}
