﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
//step2-getting connection object using microsoft.data.sqlclient
using Microsoft.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MyPractiseClassLibrary1
{
    public class MyDataBaseSample1
    {
        public void SampleADOConnectionMethod()
        {
            //step 3- creating connection object

            string strConnectionString = "Data Source=RRG;Initial Catalog=Hospital_DB;Integrated Security=True;Trust Server Certificate=True";
            SqlConnection objsqlconnection = new SqlConnection();
            objsqlconnection.ConnectionString = strConnectionString;
            objsqlconnection.Open();
            Console.WriteLine("You have successfully connected to Hospital_DB database");
            
            //step-4 creating command object
            string cmd = "select * from Specialities";
            SqlCommand objsqlcmd = new SqlCommand(cmd, objsqlconnection);
            objsqlcmd.CommandType = CommandType.Text;


            SqlDataReader objsqldr = objsqlcmd.ExecuteReader();

            if (objsqldr.HasRows)
            {
                while (objsqldr.Read())
                {
                    //Console.WriteLine(" --------Speciality ID-----------");
                    Console.WriteLine("Speciality_ID {0} Speciality_Name: {1} Speciality_Code : {2} Speciality_Description: {3}", objsqldr["Speciality_ID"], objsqldr["Speciality_Name"], objsqldr["Speciality_Code"], objsqldr["Speciality_Description"]);
                    //Console.WriteLine(" --------Speciality Name-----------");
                    //Console.WriteLine("Speciality_Name: {0}",objsqldr["Speciality_Name"]);
                    // Console.WriteLine(" --------Speciality Code-----------");
                    // Console.WriteLine("Speciality_Code: {0}",objsqldr["Speciality_Code"]);
                    // Console.WriteLine(" --------Speciality Description-----------");
                    // Console.WriteLine("Speciality_Description :{0}",objsqldr["Speciality_Description"]);
                }
            }
        }
    }
}
