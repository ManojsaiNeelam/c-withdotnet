﻿using System.Net.NetworkInformation;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

namespace MyPractiseClassLibrary1
{
    public class Class1
    {
        public int a = 123;
        public string name = "RRGALI";

        private string _firstname; //declare private variables begining with underscore
        private string _lastname;
        private string _email;
        private DateTime _dob;
        private string _address;
       // private string _fullname;
 

        public string FirstName //Properties
        {
            get
            {
                return _firstname; 
            }
            set
            { 
                _firstname = value; 
            }
        }
        public string LastName
        {
            get
            { 
                return _lastname;
            }
            set
            { 
                _lastname = value;
            }
        }
        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }
        public DateTime Dob
        {
            get
            {
                return _dob;
            }
            set
            {
                _dob = value;
            }
        }
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }

        }
        public string FullName
        {
            get
            {
                return  _firstname+"-"+_lastname;
            }
           // set
           // {
           //   _fullname = value;
            //}
        }
        public void AddTwoNumbers()//method with no parameters and no return types
        {
            //method logics
            int a = 10;
            int b = 10;
            int addition = a + b;
            Console.WriteLine(addition);
        }
        public int AddAandB()//method with return type,parameter less
        {
            int a = 10;
            int b = 30;
            int result = 0;
            result = a + b;
            return result;
        }
        public int AddCandD(int c,int d)//method with return type and parameters
        {
            int result = 0;
            result = c + d;
            return result;
        }
        public int AddEandF(int e, int f=0)//method with return type and with optional parameters
        {
            int result = 0;
            result = e + f;
            return result;
        }
        public void SubstractTwoNumbers()
        {
            int a = 10;
            int b = 5;
            int substraction = a - b;
            Console.WriteLine(substraction);
        }
        public void MultiplyTwoNumbers()
        {
            int a = 10;
            int b = 5;
            int multiplication = a * b;
            Console.WriteLine(multiplication);
        }
        public void DivideTwoNumbers()
        {
            int a = 10;
            int b = 5;
            int division = a / b;
            Console.WriteLine(division);
        }
        public Class1() //Default constructor
        {
             a = 100;
             name = "ROHITH REDDY GALI";
        }
    }
}
