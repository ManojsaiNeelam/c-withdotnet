﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPractiseClassLibrary1
{
    public class GenericsDemo<T>
    {
        List<int> numbers = new List<int>() { 11,22,33,44,55} ;
        List<string> names = new List<string>() {"Name","Ame","Mes","Edf","Sasd" } ;
        List<object> numbersandnames = new List<object>() { 123456789,"idhbvishdfjvhf"};
       

        public void GetNumbers()
        {
            foreach (var item in numbers)
            {
                Console.WriteLine(item);
            }
        }
        public void GetNames()
        {
            foreach (var item in names)
            {
                Console.WriteLine(item);
            }
        }
        public void GetNumbersAndNames()
        {
            foreach (var item in numbersandnames)
            {
                Console.WriteLine(item);
            }
        }

    }
}
