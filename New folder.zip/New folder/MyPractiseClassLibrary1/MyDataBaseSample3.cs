﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace MyPractiseClassLibrary1
{
    public class MyDataBaseSample3
    {
        public void GetAllSpecialitiesByID()
        {
            string connectionstring = "Data Source=RRG;Initial Catalog=Hospital_DB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
            SqlConnection objofsqlconnection = new SqlConnection(connectionstring);
            objofsqlconnection.Open();
            Console.WriteLine("Connection Successful");

            string command = "GetSpecialitiesbyID";
            SqlCommand objofsqlcommand = new SqlCommand(command, objofsqlconnection);
            objofsqlcommand.CommandType = CommandType.StoredProcedure;
            objofsqlcommand.Parameters.Add(new SqlParameter("id",100));

            SqlDataReader objofdatareader = objofsqlcommand.ExecuteReader();
            if(objofdatareader.HasRows)
            {
                while(objofdatareader.Read())
                {
                    Console.WriteLine("{0}:,{1}:,{2}:,{3}:", objofdatareader["Speciality_ID"], objofdatareader["Speciality_Name"], objofdatareader["Speciality_Code"], objofdatareader["Speciality_Description"]);  
                }
            }
            Console.WriteLine("connectionstring closed");

        }
    }
}
